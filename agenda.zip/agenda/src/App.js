import React, { useState, useEffect } from "react";
import "./App.css";

const ReminderForm = ({ addReminder }) => {
  const [text, setText] = useState("");
  const [scheduleType, setScheduleType] = useState("interval"); // 'specific' or 'interval'
  const [specificTime, setSpecificTime] = useState("12:00"); // Hora específica en formato 'HH:mm'
  const [intervalo, setIntervalo] = useState(1);
  const [duracion, setDuracion] = useState(1);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (text.trim() !== "") {
      if (scheduleType === "specific") {
        addReminder(text, specificTime, 1);
      } else {
        addReminder(text, intervalo, duracion);
      }
      setText("");
      setScheduleType("interval");
      setSpecificTime("12:00");
      setDuracion(1);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="reminder-form">
      <input
        type="text"
        placeholder="Agregar recordatorio"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <label>
        Tipo de Horario:
        <select
          value={scheduleType}
          onChange={(e) => setScheduleType(e.target.value)}
        >
          <option value="interval">Intervalo</option>
          <option value="specific">Específico</option>
        </select>
      </label>
      {scheduleType === "specific" && (
        <label>
          Hora Específica:
          <input
            type="time"
            value={specificTime}
            onChange={(e) => setSpecificTime(e.target.value)}
          />
        </label>
      )}
      {scheduleType === "interval" && (
        <div>
          <label>
            Intervalo (horas):
            <input
              type="number"
              min="1"
              value={intervalo}
              onChange={(e) => setIntervalo(parseInt(e.target.value, 10))}
            />
          </label>
          <label>
            Duración (días):
            <input
              type="number"
              min="1"
              value={duracion}
              onChange={(e) => setDuracion(parseInt(e.target.value, 10))}
            />
          </label>
        </div>
      )}
      <button type="submit">Agregar</button>
    </form>
  );
};

const ReminderList = ({ reminders, deleteReminder }) => {
  return (
    <ul>
      {reminders.map((reminder, index) => (
        <li key={index} className="reminder-item">
          <div>
            <strong>{reminder.text}</strong>
            <p>
              {reminder.scheduleType === "specific"
                ? `Hora Específica: ${reminder.specificTime}`
                : `Intervalo: ${reminder.intervalo} horas, Duración: ${reminder.duracion} días`}
            </p>
          </div>
          <div>
            <button onClick={() => deleteReminder(index)}>Eliminar</button>
            <br />
            <span>
              Medicamento Seleccionado tomar a las{" "}
              {reminder.schedule
                .map((time) => `${time.hour}:${time.minute}`)
                .join(", ")}
              <br />
              Fecha de finalización:{" "}
              {reminder.endDate ? reminder.endDate.toLocaleDateString() : "N/A"}
            </span>
          </div>
        </li>
      ))}
    </ul>
  );
};

function calculateSpecificSchedule(specificTime) {
  const [hours, minutes] = specificTime.split(":").map(Number);
  return [{ hour: hours, minute: minutes }];
}

function calculateSchedule(scheduleType, scheduleValue, intervalo, duracion) {
  if (scheduleType === "specific") {
    return calculateSpecificSchedule(scheduleValue);
  } else {
    const startHour = 6; // Hora de inicio a las 6 am
    const horas = 24 / intervalo;
    const schedule = Array.from(
      { length: horas * duracion },
      (_, i) => (i * intervalo + startHour) % 24
    );

    // Filtrar para mostrar cada intervalo solo una vez
    const uniqueSchedule = Array.from(new Set(schedule));

    return uniqueSchedule.map((hora) => ({
      hour: hora === 0 ? 12 : hora,
      minute: 0,
    }));
  }
}

function calculateEndDate(duracion, scheduleType) {
  if (scheduleType === "specific") {
    // Si es una hora específica, no se muestra la fecha de finalización
    return null;
  }
  const today = new Date();
  const endDate = new Date(today);
  endDate.setDate(today.getDate() + duracion);
  return endDate;
}

function App() {
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    const storedReminders = JSON.parse(localStorage.getItem("reminders")) || [];
    setReminders(storedReminders);
  }, []);

  useEffect(() => {
    localStorage.setItem("reminders", JSON.stringify(reminders));
  }, [reminders]);

  const addReminder = (text, scheduleValue, duracion) => {
    let schedule;
    let endDate = null; // Por defecto, no hay fecha de finalización

    if (typeof scheduleValue === "string") {
      // Hora específica
      schedule = calculateSpecificSchedule(scheduleValue);
    } else {
      // Intervalo
      schedule = calculateSchedule(scheduleValue, duracion);
      endDate = calculateEndDate(duracion, "interval");
    }

    const newReminder = {
      text,
      scheduleType: typeof scheduleValue === "string" ? "specific" : "interval",
      specificTime: typeof scheduleValue === "string" ? scheduleValue : "",
      intervalo: typeof scheduleValue === "string" ? 1 : scheduleValue,
      duracion,
      schedule,
      endDate,
    };
    setReminders([...reminders, newReminder]);
  };

  const deleteReminder = (index) => {
    const newReminders = [...reminders];
    newReminders.splice(index, 1);
    setReminders(newReminders);
  };

  return (
    <div className="App">
      <h1>Agenda de Medicamentos</h1>
      <ReminderForm addReminder={addReminder} />
      <ReminderList reminders={reminders} deleteReminder={deleteReminder} />
    </div>
  );
}

export default App;
